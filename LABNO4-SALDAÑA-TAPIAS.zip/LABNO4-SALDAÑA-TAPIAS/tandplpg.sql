-------------------------------------------------------------------------
/* a. Cree uno o varios disparadores (triggers) que implemente los siguiente requerimientos 
para la relación enrolls 
  i. Al agregar una tupla en enrolls, en caso de que la nota sea negativa, cero (0.0) 
  o mayor de 5.00 se debe generar una excepción indicando que el valor a guardar en grade es 
  incorrecto o invalido.*/
  
  /* ii. Durante la actualización de un registro si el valor grade es modificado, usando RAISE NOTICE 
	se debe presentar un mensaje indicando el cambio, si es igual al valor grade en la tabla se debe indicar 
	que el valor no ha sido modificado. Si el grade a actualizar es negativo, cero o mayor de cinco use RAISE 
	EXCEPTION. */

create or REPLACE FUNCTION FN_enrols_insert_Grade() returns TRIGGER
AS
$$
BEGIN
if (TG_OP = 'INSERT') THEN
	if  new.grade <= 0.0 or new.grade > 5.00 THEN
	raise EXCEPTION 'El valor a guardar en la nota del curso es incorrecto o invalido.';
	end if;
END IF;

IF(TG_OP = 'UPDATE') THEN
	if  new.grade <= 0.0 or new.grade > 5.00 THEN
	raise EXCEPTION 'El valor a guardar en la nota del curso es incorrecto o invalido.';
	
    ELSE
    	if NEW.grade != old.grade THEN
        raise NOTICE 'Se cambio el valor de la nota correctamente.';
        RETURN new;
        end if;
        
        if new.grade = old.grade THEN
        raise NOTICE 'El valor grade no se ha modificado.';
        end if;
    end if;
end if;


return new;
end
$$
LANGUAGE plpgsql;

create or REPLACE TRIGGER TR_enrols_insert_Grade BEFORE INSERT or UPDATE on enrols
for each row 
execute PROCEDURE FN_enrols_insert_Grade();

-------------------------------------------------------------------------
/* b. Cree un procedimiento create_teaches que automáticamente agregue un registro a teaches. Este recibe dos 
argumentos un identificador de instructor instructor_id y un identificador de course_id. Se asume que ambos existen 
en la base de datos. 
	i. Este procedimiento debe verificar que el curso exista en la oferta de cursos.
    ii. Use curse_id, sec_id, year y semester de la oferta de curso y instructor_id el para insertar en teaches.*/
    
create or replace FUNCTION FN_teaches_create_teach(INTEGER, INTEGER) RETURNs void
AS
$$
DECLARE 
course_id4 INTEGER:= NULL;
sec_id3 INTEGER := NULL;
year1 INTEGER := NULL;
semester1 INTEGER := NULL;

BEGIN

SELECT course_id1 into course_id4 FROM course_offering where course_id1 = $1; 
	
	if course_id4 is NULL then
    raise notice 'No se puede añadir al instructor, porque el curso ingresado, no esta en la oferta de cursos. ';
	end if;
   	
    	SELECT sec_id into sec_id3 FROM course_offering where course_id1 = $1;
    	SELECT year into year1 FROM course_offering where course_id1 = $1;
    	SELECT semester into semester1 FROM course_offering where course_id1 = $1;
    
    	INSERT INTO teaches (course_id3, sec_id2, semester, year, instructor_id1) VALUES 
    	($1, sec_id3, semester1, year1, $2);
     	
END
$$
LANGUAGE plpgsql;

-------------------------------------------------------------------------









