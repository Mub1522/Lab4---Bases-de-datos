-------------------------------------------------------------------------
--Creacion de la tabla student y una sequence para el student_id
create SEQUENCE if not EXISTS seqstudent_id START with 7488 INCREMENT BY 168;

create table if not EXISTS student(
  student_id INTEGER PRIMARY KEY DEFAULT nextval('seqstudent_id'),
  name VARCHAR(150),
  program VARCHAR(200)
);

-------------------------------------------------------------------------
--Creacion de la tabla instructor
create TABLE if not EXISTS instructor(
  instructor_id INTEGER PRIMARY KEY,
  name VARCHAR(150),
  dept VARCHAR(200),
  title VARCHAR(200)
);

-------------------------------------------------------------------------
--Creacion de la tabla course y una sequence para el course_id
create SEQUENCE if not EXISTS seqcourse_id START with 837827 INCREMENT BY 23;

create table if not EXISTS course(
  course_id INTEGER PRIMARY KEY DEFAULT nextval('seqcourse_id'),
  title VARCHAR(200),
  syllabus VARCHAR(200),
  credits INTEGER
);

-------------------------------------------------------------------------
--Creacion de la tabla course_offering
CREATE table if not EXISTS course_offering(
  course_id1 INTEGER,
  sec_id INTEGER PRIMARY KEY,
  year INTEGER,
  semester INTEGER,
  time VARCHAR(150),
  classrom INTEGER,
  FOREIGN KEY (course_id1) REFERENCES course (course_id)
);

-------------------------------------------------------------------------
--Creacion de la tabla enrols
CREATE table if not EXISTS enrols(
  student_id1 INTEGER,
  course_id2 INTEGER,
  sec_id1 INTEGER PRIMARY KEY,
  semester INTEGER,
  year INTEGER,
  grade NUMERIC(3,2)CONSTRAINT Enr_MayorAuno_MenorAcinco CHECK (grade >= 1 and grade <= 5),
  FOREIGN key (student_id1) REFERENCES student (student_id),
  FOREIGN key (course_id2) REFERENCES course (course_id)
);

-------------------------------------------------------------------------
--Creacion de la tabla teaches
CREATE table if not EXISTS teaches(
  course_id3 INTEGER,
  sec_id2 INTEGER,
  semester INTEGER,
  year INTEGER,
  instructor_id1 INTEGER,
  FOREIGN KEY (course_id3) REFERENCES course (course_id),
  FOREIGN KEY (instructor_id1 ) REFERENCES instructor (instructor_id)
);

-------------------------------------------------------------------------
--Creacion de la tabla requires
CREATE table if not EXISTS requires(
  main_course INTEGER,
  prerequisite INTEGER,
  PRIMARY KEY(main_course, prerequisite),
  FOREIGN KEY (main_course) REFERENCES course (course_id),
  FOREIGN KEY (prerequisite) REFERENCES course (course_id)
);

-------------------------------------------------------------------------

