-------------------------------------------------------------------------
-- a. Encuentre el dept, title de los instructores registrados en la base de datos.

SELECT dept, title FROM instructor;

-------------------------------------------------------------------------
-- b. Indique el nombre y programa del estudiante con student_id = 7656

SELECT name, program from student WHERE student_id = 7656;

-------------------------------------------------------------------------
-- c. Encuentre los nombres de todos los estudiantes que se han matriculado en el curso con course_id = 837873

SELECT s.name, s.program
from student as s
join enrols  as e
on s.student_id = e.student_id1
where e.course_id2 = 837873;

-------------------------------------------------------------------------
/* d. Cree una vista llamada better_students que presente los estudiantes que obtuvieron las notas más altas 
por cada semestre entre los años 1900 y 2018 */

create view better_students
as 
SELECT s.name
from student as s
join enrols  as e
on s.student_id = e.student_id1
where e.year >= 1900 and e.year <= 2018 and e.grade > 4.0; 





