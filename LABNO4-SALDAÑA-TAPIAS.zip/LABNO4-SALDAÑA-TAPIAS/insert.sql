-------------------------------------------------------------------------
--Insertando datos en la tabla student

INSERT into student (name, program) VALUES
('Uta Herrera', 'Programa 1'),
('Brett Fuentes', 'Programa 1'),
('Abigail Sherman', 'Programa 1'),
('Matthew Vaughan', 'Programa 2'),
('Kay Donaldson', 'Programa 2');

-------------------------------------------------------------------------
--Insertando datos en la tabla instructor

insert into instructor (instructor_id, name, dept, title) VALUES
(1, 'Flynn Hensley', 'Departamento 1', 'Licenciatura'),
(2, 'Adrienne Olsen', 'Departamento 1', 'Licenciatura'),
(3, 'Kirsten Waters', 'Departamento 1', 'Licenciatura'),
(4, 'Mollie Fletcher', 'Departamento 2', 'ingenieria'),
(5, 'Alexander Duncan', 'Departamento 2', 'ingenieria');

-------------------------------------------------------------------------
--Insertando datos en la tabla course

INSERT into course (title, syllabus, credits) VALUES
('Curso 1', 'Programa 1', 4),
('Curso 2', 'Programa 1', 4),
('Curso 3', 'Programa 1', 4),
('Curso 4', 'Programa 2', 4),
('Curso 5', 'Programa 2', 4);

-------------------------------------------------------------------------
--Insertando datos en la tabla course_offering

INSERT INTO course_offering (course_id1, sec_id, YEAR,semester, time, classrom) VALUES
(837827, 1, 1900, 4, '4 horas', 10),
(837850, 2, 2018, 4, '4 horas', 10),
(837873, 3, 2000, 4, '4 horas', 10),
(837896, 4, 2022, 4, '4 horas', 10),
(837919, 5, 2022, 4, '4 horas', 10);

-------------------------------------------------------------------------
--Insertando datos en la tabla enrols

INSERT into enrols (student_id1, course_id2, sec_id1, semester, year, grade) VALUES
(7488, 837827, 1, 4, 1900, 4.50),
(7656, 837850, 2, 4, 2018, 4.30),
(7824, 837873, 3, 4, 2000, 3.50),
(7992, 837896, 4, 4, 2022, 4.00),
(8160, 837919, 5, 4, 2022, 4.00);

-------------------------------------------------------------------------
--Insertando datos en la tabla teaches

insert into teaches (course_id3, sec_id2, semester, year, instructor_id1) VALUES 
(837827, 1, 4, 1900, 1),
(837850, 2, 4, 2018, 2),
(837873, 3, 4, 2000, 3),
(837896, 4, 4, 2022, 4),
(837919, 5, 4, 2022, 5);

-------------------------------------------------------------------------
--Insertando datos en la tabla requires

INSERT INTO requires (main_course, prerequisite) VALUES
(837827, 837850),
(837850, 837827),
(837873, 837827),
(837896, 837919),
(837919, 837896);

-------------------------------------------------------------------------
