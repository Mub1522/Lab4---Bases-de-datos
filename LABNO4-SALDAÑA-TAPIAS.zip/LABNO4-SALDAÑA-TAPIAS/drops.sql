-------------------------------------------------------------------------
-- 1. eliminacion de las tablas, sequencias y vistas
drop VIEW better_students;

-------------------------------------------------------------------------
-- 2. eliminacion de las tablas, sequencias y vistas
drop TABLE requires;
drop table teaches;
drop table enrols;
drop table course_offering; 
drop TABLE course;
drop SEQUENCE seqcourse_id;
drop table instructor;
drop table student;
drop SEQUENCE seqstudent_id;

-------------------------------------------------------------------------
-- 3. Eliminacion de los trigger y funciones
drop TRIGGER TR_enrols_insert_Grade;
drop FUNCTION FN_enrols_insert_Grade;
drop FUNCTION FN_teaches_create_teach;